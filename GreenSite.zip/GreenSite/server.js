const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Настройки по умолчанию
let settings = {
    saveTickets: true
};

// Загрузка настроек
try {
    const data = fs.readFileSync('settings.json');
    settings = JSON.parse(data);
} catch (err) {
    saveSettings();
}

function saveSettings() {
    fs.writeFileSync('settings.json', JSON.stringify(settings));
}

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Папка для сохранения сообщений
const messagesDir = path.join(__dirname, 'usrmsg');
if (!fs.existsSync(messagesDir)) {
    fs.mkdirSync(messagesDir);
}

// Функция для санитизации имени файла
function sanitizeFilename(name) {
    return name.replace(/[^а-яА-Яa-zA-Z0-9_\-]/g, '').replace(/\s+/g, '_');
}

// Функция для генерации случайного трёхзначного числа
function generateRandomThreeDigits() {
    return Math.floor(100 + Math.random() * 900); // Генерация числа от 100 до 999
}

// API для настроек
app.get('/api/settings', (req, res) => {
    res.json(settings);
});

app.post('/api/settings', (req, res) => {
    settings = {...settings, ...req.body};
    saveSettings();
    res.json({success: true});
});

// Защита админ-панели
app.use('/admin*', (req, res, next) => {
    if(req.path.includes('login')) return next();
    const auth = req.headers.authorization;
    if(auth === 'EntPrest') return next();
    res.status(403).send('Доступ запрещён');
});

// Обработчик POST-запроса для сохранения сообщений
app.post('/save', (req, res) => {
    const { product_url, name, phone, contact, comment } = req.body;

    // Проверка обязательных полей
    if (!product_url || !name || !phone || !contact) {
        return res.status(400).json({ success: false, error: 'Все поля обязательны для заполнения' });
    }

    // Форматирование содержимого файла
    const content = `=== Запрос получения денег за отзыв ===\n` +
        `Дата: ${new Date().toISOString()}\n\n` +
        `Данные:\n` +
        `Имя: ${name}\n` +
        `Телефон: ${phone}\n` +
        `Контакт: ${contact}\n` +
        `Ссылка на товар: ${product_url}\n\n` +
        `Комментарии:\n${comment || 'Отсутствуют'}`;

    // Генерация имени файла
    const randomDigits = generateRandomThreeDigits(); // Трёхзначное число
    const filename = `${sanitizeFilename(name)}_${randomDigits}.message`;
    const filepath = path.join(messagesDir, filename);

    // Сохранение файла
    fs.writeFile(filepath, content, (err) => {
        if (err) {
            console.error('Ошибка при сохранении файла:', err);
            return res.status(500).json({ success: false, error: 'Ошибка при сохранении файла' });
        }

        res.json({ success: true });
    });
});

// API для работы с файлами и тегами
const tagsFile = path.join(__dirname, 'tags.json');
let tags = {};
try {
    tags = JSON.parse(fs.readFileSync(tagsFile));
} catch (e) {
    tags = {};
}

app.get('/api/files', (req, res) => {
    fs.readdir(messagesDir, (err, files) => {
        res.json({
            files: files.filter(f => f.endsWith('.message')),
            tags
        });
    });
});

app.get('/api/file/:name', (req, res) => {
    const filePath = path.join(messagesDir, req.params.name);
    fs.readFile(filePath, 'utf8', (err, content) => {
        err ? res.status(404).send() : res.json({content});
    });
});

app.post('/api/tag', (req, res) => {
    tags[req.body.file] = req.body.tag;
    fs.writeFileSync(tagsFile, JSON.stringify(tags));
    res.json({success: true});
});

app.delete('/api/file/:name', (req, res) => {
    const filePath = path.join(messagesDir, req.params.name);
    fs.unlink(filePath, () => {
        delete tags[req.params.name];
        fs.writeFileSync(tagsFile, JSON.stringify(tags));
        res.json({success: true});
    });
});

app.post('/api/rename', (req, res) => {
    const oldPath = path.join(messagesDir, req.body.oldName);
    const newPath = path.join(messagesDir, req.body.newName);
    
    fs.rename(oldPath, newPath, (err) => {
        if(err) return res.status(500).json({error: 'Ошибка переименования'});
        
        tags[req.body.newName] = tags[req.body.oldName];
        delete tags[req.body.oldName];
        fs.writeFileSync(tagsFile, JSON.stringify(tags));
        
        res.json({success: true});
    });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});